let noOfButtons = document.querySelectorAll(".drum").length;
let currMode = "light";
let bkGnd = document.querySelector("body");
let heading = document.querySelector("h1");
let tiles = document.querySelectorAll(".drum");
let toggle = document.querySelector(".tglbtn");

for (let i = 0; i < noOfButtons; i++) {
  document.querySelectorAll(".drum")[i].addEventListener("click", handleClick);
}
function handleClick() {
  let btnInnerHtml = this.innerHTML;
  makeSound(btnInnerHtml);
  btnAnimation(btnInnerHtml);
}

document.addEventListener("keydown", function (event) {
  makeSound(event.key);
  btnAnimation(event.key);
});

function makeSound(key) {
  switch (key) {
    case "w":
      let crash = new Audio("sounds/crash.mp3");
      crash.play();
      break;

    case "a":
      let kickBass = new Audio("sounds/kick-bass.mp3");
      kickBass.play();
      break;

    case "s":
      let snare = new Audio("sounds/snare.mp3");
      snare.play();
      break;

    case "d":
      let tom1 = new Audio("sounds/tom-1.mp3");
      tom1.play();
      break;

    case "j":
      let tom2 = new Audio("sounds/tom-2.mp3");
      tom2.play();
      break;

    case "k":
      let tom3 = new Audio("sounds/tom-3.mp3");
      tom3.play();
      break;

    case "l":
      let tom4 = new Audio("sounds/tom-4.mp3");
      tom4.play();
      break;

    default:
      console.log(this.innerHTML);
  }
}

function btnAnimation(currentKey) {
  var activeBtn = document.querySelector("." + currentKey);
  activeBtn.classList.add("pressed");
  setTimeout(() => {
    activeBtn.classList.remove("pressed");
  }, 200);
}



toggle.addEventListener("click", () => {
  if (currMode === "light") {
    currMode = "dark";
    bkGnd.setAttribute("class", "bodydrk");
    heading.setAttribute("class", "h1drk");
    tiles.setAttribute("class", "drumdrk");
    toggle.setAttribute("class", "tglbtndrk");
  } else {
    currMode = "light";
    bkGnd.setAttribute("class", "body");
    heading.setAttribute("class", "h1");
    tiles.setAttribute("class", "drum");
    toggle.setAttribute("class", "tglbtn");
  }
});
